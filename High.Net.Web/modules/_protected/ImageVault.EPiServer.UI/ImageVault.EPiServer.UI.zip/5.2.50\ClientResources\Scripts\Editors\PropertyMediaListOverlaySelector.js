﻿define([
//dojo
    "dojo/_base/declare",
//dijit
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
//imagevault
    "imagevault/RequireModule!ImageVault.EPiServer.UI"
],
function (
//dojo
    declare,
//dijit
    _Widget,
    _TemplatedMixin,
    appModule
) {

    return declare([_Widget, _TemplatedMixin], {

        templateString: '<div/>',
        postCreate: function () {
            // call base implementation
            this.inherited(arguments);
        },
        //need to fake some properties/methods to avoid script errors.
        position: { isChanged: false },
        resize: function () { },
        refresh: function () { }
    });
});