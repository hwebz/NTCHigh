﻿define([
//dojo
    "dojo/_base/declare",
//dijit
    "dijit/_Widget",
    "dijit/_TemplatedMixin"

],
function (
//dojo
    declare,
//dijit
    _Widget,
    _TemplatedMixin

) {

    return declare([_Widget, _TemplatedMixin], {

        templateString: '<span data-dojo-attach-point="errorSpan" class="error" style="text-align: left;line-height: 45px;"/>',
        errorMessage: null,
        postCreate: function () {
            this.errorSpan.innerHTML = this.errorMessage;
            // call base implementation
            this.inherited(arguments);
        }
    });
});
