(function ($, ns) {
	var editor = function (config) {
		this.init(config);

		return this;
	};

	editor.prototype = {
		//properties
		currentEffects: null,
		editableMediaUrl: null,
		editableMediaContentType: null,
		//methods
		init: function (config) {
			$.extend(this, config);

			var self = this;

			var videoEffects = [];
			if (this.currentEffects && this.currentEffects.length > 0) {
				$.each(this.currentEffects, function (idx, ob) {
					if (ob.$type.indexOf("ImageVault.Common.Data.Effects.TrimEffect,") > -1) {
						if (!ob.Start) {
							ob.Start = 0;
						}
						videoEffects.push(ob);
					}
				});
			}

			//Load the DOM except for the video-tag
			this.setupDOM();

			//Make sure we are using a media that can be shown in the editor
			this.loadEditableMedia(function () {
				//Load the video tag with start/stop metadata
				if (videoEffects.length > 0) {
					self.setupVideoTag($(videoEffects).get(-1).Start, $(videoEffects).get(-1).Stop);
				} else {
					self.setupVideoTag(0, -1);
				}
				// !!REMOVE TEH FOLLOWING LINE TO DISPLAY THE TRIM-TOOL!!
				//$('#canvas').attr('style', 'display:none');			    
			    //Load the script
				$.getScript("videoEditor2.js", $.proxy(function (data, textStatus, jqxhr) {
					// todo: we need some way to know when script has finished executing (e.g. callback)
					this.$preloadobj.fadeOut(400);
				}, self));
			});
		},

		initPlayerDone: function () {
			this.$preloadobj.fadeOut(400);
		},
		setupDOM: function () {
			// todo: read start/stop effect and input correct values in initPlayer
			// todo: refactor how script is added perhaps?
			// todo: display $preloadobj until videoEditor2.js has finished loading


			$('<div id="player1" class="player">' +
                    '<div id="canvas">' +
                        '<canvas id="myCanvas">' +
                            'Your browser does not support the HTML5 canvas tag.' +
                        '</canvas>' +
						'<div id="editor-actions" class="video-actions">' +
							'<a id="save-editor" href="#" class="propertymedia-btn save-button">OK</a>' +
						'</div>' +
                    '</div>' +
              '</div>').appendTo("#editor");
			//'<script src="videoEditor2.js"></script>').appendTo("#editor");//.then(this.$preloadobj.fadeOut(400));
		},
		setupVideoTag: function (start, stop) {
			$('#player1').prepend(
				'<div id="video">' +
					'<video id="myVideo" width="840px" height="550px" onloadedmetadata="videoPlayer = initPlayer(\'myVideo\', \'myCanvas\', {start:' + start + ', stop:' + stop + ', editor: true})">' +
						'<source src="' + this.editableMediaUrl + '" type="' + this.editableMediaContentType + '">' +
							'Your browser does not support the video tag.' +
					'</video>' +
				'</div>');
		},
		loadEditableMedia: function (callback) {
			var parameters = {
				Filter: { Id: [this.imageId] },
				Populate: {
					MediaFormats: [{
						$type: "ImageVault.Common.Data.WebMediaFormat,ImageVault.Common",
						Effects: [{ $type: "ImageVault.Common.Data.Effects.ChangeOutputFormatEffect,ImageVault.Common", ContentType: "video/mp4" }]
					}]
				},
				MediaUrlBase: this.mediaUrlBase
			};

			//we stringify the parameters first before passing to the client
			//the client resides in the parent window and for IE that means passing arrays over windows makes them to objects (assocciative arrays)
			//thus the json gets all mixed up.
			var json = JSON.stringify(parameters);
			this.client.json("MediaService/Find", json, $.proxy(function (x) {
				if (x == null) {
					alert("Error calling ImageVault Core. [" + this.client._lastError.message + " (status:" + this.client._lastError.status + ")]");
					this.callback(null);
					return;
				}
				var index = 0;
				if (x[0].MediaConversions[index].MediaFormatName != "System")
					index = 1;

				this.editableMediaUrl = x[0].MediaConversions[index].Url;
				this.editableMediaContentType = x[0].MediaConversions[index].ContentType;
				callback();
			}, this));
		},
		updateCurrentEffects: function () {
			var effectArray = [];

			//ChangeOutputFormat Effect
			effectArray.push({ $type: "ImageVault.Common.Data.Effects.ChangeOutputFormatEffect,ImageVault.Common", ContentType: "video/mp4" });

			//Trim Effect
			effectArray.push({ $type: "ImageVault.Common.Data.Effects.TrimEffect,ImageVault.Common", Start: videoPlayer.getStartTime(), Stop: videoPlayer.getStopTime() });

			this.currentEffects = effectArray;
		}
	};

	ns.VideoEditor = editor;
})(jQuery, window.ImageVault != null ? window.ImageVault : window.ImageVault = {});
