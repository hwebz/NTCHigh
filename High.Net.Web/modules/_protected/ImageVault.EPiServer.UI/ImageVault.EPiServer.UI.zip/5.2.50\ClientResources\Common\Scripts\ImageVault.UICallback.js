﻿(function ($, ns) {

	var c = function (config) {
		$.extend(this, config);

		//problem with arrays passed from other frames/windows in IE
		//http://stackoverflow.com/questions/1058427/how-to-detect-if-a-variable-is-an-array/4029057#4029057
		//fixes the isArray function so it works for all browsers
		var toString = Object.prototype.toString,
        jscript = /*@cc_on@_jscript_version@*/ + 0;

		// jscript will be 0 for browsers other than IE
		if (!jscript) {
			this.isArray = Array.isArray || function (obj) {
				return toString.call(obj) == "[object Array]";
			};
		} else {
			this.isArray = function (obj) {
				return "constructor" in obj && Object.prototype.toString.call(obj) == "[object Array]";
			};
		}
		return this;
	};

	c.prototype = {
		//Properties
		ivWinRefs: new Object(),

		//methods
		isArray: null, //instanced in constructor
		isString: function (obj) {
		    return (Object.prototype.toString.call(obj) == "[object String]");
		},
		isJsonString: function (obj) {
		    if (this.isString(obj)) {
		        return ((obj.slice(0, 1) == "{" && obj.slice(-1) == "}") || (obj.slice(0, 2) == "[{" && obj.slice(-2) == "}]"));
		    }
		    return false;
		},
		RegisterOpener: function (name, expectArrayResponse, callback) {
			this.ivWinRefs[name] = { 'expectArrayResponse': expectArrayResponse, 'callback': callback };
		},
		IVCallback: function (win, data) {

			var o = this.ivWinRefs[win.name];
			if (!o) {
				throw "Cannot find callback registration for window named " + win.name + ". Did you forget to call RegisterOpener with correct name?";
			}
		    
			if (this.isJsonString(data)) {
			    data = JSON.parse(data);
			}
			else if (($.browser.msie && (document.documentMode === undefined || document.documentMode < 10)) && this.isString(data)) {
			    throw "Browser compability problem, when using IE versions below 10. Please upgrade your ImageVault4 UI installation or your browser.";
			}

			if (o.expectArrayResponse) {
				//Jquery (1.3 anyway) isArray dont work with arrays from other frames/windows in IE
				//if (!$.isArray(data)) {
				if (!this.isArray(data)) {
					var arr = new Array();
					if (data.length || data[0]) {
						$.each(data, function (idx, val) {
							arr.push(val);
						});
					}
					else {
					arr.push(data);
					}
					data = arr;
				}
			}
			data = JSON.parse(JSON.stringify(data));
			o.callback(data);
		}
	};
	ns.UiCallback = c;
})(jQuery, window.ImageVault != null ? window.ImageVault : window.ImageVault = {});

var iv = window.ImageVault;

//setup singleton instance
if (!iv.UiCallback) {
	throw "ImageVault.UiCallback registration failed, cannot continue";
}
if (!iv.UiCallback.Instance) {
	iv.UiCallback.Instance = new iv.UiCallback();
}
//setup window callback function
if (!window.IVCallback) {
	window.IVCallback = function (win, data) { iv.UiCallback.Instance.IVCallback(win, data); };
}