﻿define([
//dojo
    "dojo",
    "require",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/request/script",
    "dojo/dom-construct",
    "dojo/dom-style"
],
function(
//dojo
    dojo,
    require,
    declare,
    lang,
    script,
    domConstruct,
    domStyle
) {
    return declare([], {
        // Append error div to this node
        ErrorNode: null,
        
        ShowError: function (errorMsg) {
            if (!this.ErrorNode) {
                alert(errorMsg);
            } else {
                this._renderError(errorMsg);
            }
                
        },
        _renderError: function (errorMsg) {
            if (errorMsg) {
                var inner = "<span style='background: red; color: white; visibility: visible; padding: 2px; border: 1px solid red; border-radius: 4px; margin: 2px;'>" + errorMsg + "</span>";
                this.error = domConstruct.create("div", { innerHTML: inner }, this.ErrorNode, "last");
                domStyle.set(this.error, { "width": "100%", "margin-top":"2px", "margin-bottom":"2px" });
            }
        },
    });
});